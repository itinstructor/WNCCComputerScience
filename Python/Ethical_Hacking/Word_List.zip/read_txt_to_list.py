#!/usr/bin/env python3
"""
    Name: read_txt_to_list.py
    Author:
    Created:
    Read txt file of words to list
"""


def main():
    """Text read function on text file."""
    # Counter to add a counter number to each word
    count = 1

    # Enter file name to test
    filename = input("Enter txt file to read: ")

    # Read file into a list
    word_list = read_to_list(filename)
    # For each word in the list, Print the word and the count
    for word in word_list:
        print(f"{count}: {word}")
        count += 1


def read_to_list(filename: str) -> list[str]:
    """ Read txt file, split lines into a list

    Parameter:
        str: filename
    Return:word
        list[str]
    """
    with open(filename, "r") as file_handle:
        # Pass the file handle object to reader() to get the reader object
        data = file_handle.read()

        # Split the words in the text file by the Enter key \n
        word_list = data.split("\n")

        return word_list


# If a standalone program, call the main function
# Else, use as a module
if __name__ == "__main__":
    main()
